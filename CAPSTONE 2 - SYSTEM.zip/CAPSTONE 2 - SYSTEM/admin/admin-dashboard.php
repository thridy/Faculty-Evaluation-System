<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Logo/mja-logo.png">
    <?php include('../header.php'); ?>
    <!--css file-->
    <link rel="stylesheet" href="../css/sidebar.css" />
</head>
<body>
    <?php session_start(); ?>
    <?php include('navigation.php'); ?>
    
    <!-- CONTENTS HERE  -->
    <h1 style="text-align:center; padding-top: 130px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>
    <h1 style="text-align:center; padding-top: 65px;">
    DASHBOARD SECTION --- ID NUMBER: <?php echo $_SESSION['user_id']; ?>
    </h1>

    <?php include('footer.php'); ?>
    
</body>
</html>
